package org.manager;

import org.pages.SerachPage;

public class PageObjectManager {
	
	private SerachPage searchPage;
	
	public SerachPage getSearchPage() {
		return (searchPage == null) ? searchPage = new SerachPage() : searchPage;
	}

}
