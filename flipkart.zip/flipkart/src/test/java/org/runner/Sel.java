package org.runner;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Sel {
	
	@Test
	public void tc1() throws IOException, InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new  ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(options);
		
		driver.get("https://www.flipkart.com/");
		
		WebElement btnCl = driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']"));
		btnCl.click();
		
		WebElement searchBox = driver.findElement(By.name("q"));
		searchBox.sendKeys("tv",Keys.ENTER);
		
		Thread.sleep(3000);
		
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		File des = new File("C:\\Users\\Ramesh Riyo\\eclipse-workspace\\flipkart\\target\\index.png"); 
		FileUtils.copyFile(src, des);
		
	}
	
	
	

}
