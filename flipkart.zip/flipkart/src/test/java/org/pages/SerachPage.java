package org.pages;

import org.baseclass.BaseClass;
import org.manager.PageObjectManager;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SerachPage extends BaseClass {
	public SerachPage() {
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(name = "q")
	private WebElement searchBox;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement searchlick;

	@FindBy(xpath = "//button[@class='_2KpZ6l _2doB4z']") // button[@class='_2KpZ6l _2doB4z']
	private WebElement popUp;

	public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getSearchlick() {
		return searchlick;
	}

	public WebElement getPopUp() {
		return popUp;
	}

	

}
