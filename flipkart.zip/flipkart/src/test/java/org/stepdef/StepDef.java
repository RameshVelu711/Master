package org.stepdef;

import java.awt.AWTException;

import org.baseclass.BaseClass;
import org.manager.PageObjectManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDef extends BaseClass {
	
	PageObjectManager pom = new PageObjectManager();

	@Given("User should launch on flipkart application")
	public void user_should_launch_on_flipkart_application() {

		launchApplication("chrome");
		enterUrl("https://www.flipkart.com/");
	}

	@When("User should handle the popup")
	public void user_should_handle_the_popup() throws AWTException {
		
		pom.getSearchPage().getPopUp().click();
	}

	@When("User should enter the product in search box {string}")
	public void user_should_enter_the_product_in_search_box(String product) {
		pom.getSearchPage().getSearchBox().sendKeys(product);
	}

	@When("User should enter search icion")
	public void user_should_enter_search_icion() {
		pom.getSearchPage().getSearchlick().click();
	}

	@Then("user should verify the searched product is displayed")
	public void user_should_verify_the_searched_product_is_displayed() {
	}

}
